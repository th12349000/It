# Multiplayer 3D Shooter (Touch + Desktop)

A WebGL multiplayer FPS with **Three.js** and **Socket.io**. Works on desktop (mouse/keyboard) and mobile (touch HUD).

## Controls
- **Desktop**: WASD to move, Mouse to aim (click Play to lock), Left-click to shoot, Space to jump, Shift to sprint.
- **Mobile/iPad**: Left circular pad to move, Right pad to aim, Red button to shoot, Green button to jump.

## Run locally
```bash
npm i
npm start
# open http://localhost:3000
```
Open in two tabs/devices to test multiplayer.

## Deploy
- **Server** (`server/`): Deploy to Render/Fly/Railway and run `node server/server.js`.
- **Client** (`public/`): Deploy to Netlify (drag-drop the `public/` folder).
- Set `public/config.js` → `SERVER_URL` to your deployed server URL when in production.

## Notes
- Networking is simple (hitscan, naive hit test). Upgrade with real capsules, lag compensation, and interpolation if you like.
- Visuals include bloom, SSAO, shadows; tune based on device performance.
