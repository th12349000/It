// public/config.js
export const SERVER_URL = (location.hostname === 'localhost')
  ? 'http://localhost:3000'
  : 'https://YOUR-PROD-SERVER-URL'; // <- update after deploying the server
