// server/server.js
// Minimal Socket.io game loop server (authoritative-ish for hits and respawn)

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' },
});

// Serve static client when hosting both together (optional)
app.use(express.static('public'));

// Game state
const players = new Map(); // id -> {id, name, x,y,z, rx,ry,rz, hp, lastShot}

function spawnPoint() {
  const range = 18;
  return { x: (Math.random()-0.5)*2*range, y: 1.1, z: (Math.random()-0.5)*2*range };
}

io.on('connection', (socket) => {
  const id = socket.id;
  const spawn = spawnPoint();
  const player = {
    id,
    name: `Player-${id.slice(0,4)}`,
    x: spawn.x, y: spawn.y, z: spawn.z,
    rx: 0, ry: 0, rz: 0,
    hp: 100,
    lastShot: 0,
  };
  players.set(id, player);

  socket.emit('init', { id, players: Array.from(players.values()) });
  socket.broadcast.emit('join', player);

  socket.on('move', (data) => {
    const p = players.get(id);
    if (!p) return;
    p.x = data.x; p.y = data.y; p.z = data.z;
    p.rx = data.rx; p.ry = data.ry; p.rz = data.rz;
  });

  socket.on('shoot', (shot) => {
    const now = Date.now();
    const p = players.get(id);
    if (!p) return;
    if (now - p.lastShot < 120) return;
    p.lastShot = now;

    // shot: { origin:{x,y,z}, dir:{x,y,z}, maxDist }
    const RADIUS = 0.6;
    let hit = null;

    for (const [pid, target] of players) {
      if (pid === id) continue;
      const ox = shot.origin.x, oy = shot.origin.y, oz = shot.origin.z;
      const dx = shot.dir.x, dy = shot.dir.y, dz = shot.dir.z;
      const cx = target.x, cy = target.y + 0.9, cz = target.z;
      const vx = cx - ox, vy = cy - oy, vz = cz - oz;
      const t = Math.max(0, Math.min(shot.maxDist, (vx*dx + vy*dy + vz*dz)));
      const qx = ox + dx * t, qy = oy + dy * t, qz = oz + dz * t;
      const dist2 = (qx-cx)**2 + (qy-cy)**2 + (qz-cz)**2;
      if (dist2 <= RADIUS*RADIUS) { hit = { pid, t }; break; }
    }

    if (hit) {
      const target = players.get(hit.pid);
      if (target) {
        const dmg = 25;
        target.hp = Math.max(0, target.hp - dmg);
        io.emit('hit', { attacker: id, victim: target.id, hp: target.hp });
        if (target.hp <= 0) {
          setTimeout(() => {
            const s = spawnPoint();
            target.x = s.x; target.y = s.y; target.z = s.z;
            target.hp = 100;
            io.emit('respawn', { id: target.id, x: target.x, y: target.y, z: target.z, hp: target.hp });
          }, 800);
        }
      }
    }

    io.emit('tracer', { id, origin: shot.origin, dir: shot.dir });
  });

  socket.on('disconnect', () => {
    players.delete(id);
    socket.broadcast.emit('leave', { id });
  });
});

setInterval(() => {
  io.emit('state', Array.from(players.values()));
}, 66);

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server on http://localhost:${PORT}`));
